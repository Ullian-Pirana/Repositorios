Nessa pasta tem os arquivos do codigo feito para o projeto final da materia
de back-end, do 2 semestre; nesse projeto nos foi passado um documento que pedia
para programarmos um sistema bancario, utilizando como base as especificações
passadas no documento.